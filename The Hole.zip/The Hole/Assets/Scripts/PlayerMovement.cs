﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed;

    Rigidbody2D rb;

    Animator m_Animator;

    public GameObject dave;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        m_Animator = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {

    }

    void Update()
    {

        float moveH = Input.GetAxis("Horizontal");
        float moveV = Input.GetAxis("Vertical");

        rb.velocity = new Vector2(speed * moveH, speed * moveV);

        if (moveH > 0)
        {
            dave.transform.localRotation = Quaternion.Euler(0, 180, 0);
            if (m_Animator.GetBool("notMoving"))
            {
                m_Animator.SetBool("notMoving", false);
                Debug.Log("Set bool to false");
            }
        }
        if (moveH < 0)
        {
            dave.transform.localRotation = Quaternion.Euler(0, 0, 0);

            if (m_Animator.GetBool("notMoving"))
            {
                m_Animator.SetBool("notMoving", false);
                Debug.Log("Set bool to false");
            }
        }
        if (moveH == 0)
        {
            if (m_Animator.GetBool("notMoving") == false)
            {
                m_Animator.SetBool("notMoving", true);
                Debug.Log("Set bool to true");
            }
        }
    }
}