﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class NpcInventoryUi : MonoBehaviour {

    [SerializeField]
    private Button[] buttonsUi = null;

    private NpcInventory _cpuInventory = null;

    public void SetCpu(NpcInventory cpuInventory) {
        if (_cpuInventory != cpuInventory) { 
            HideActualCpuInventory();
            this.gameObject.SetActive(true);
            this._cpuInventory = cpuInventory;

            for (int i = 0; i < buttonsUi.Length; i++) {
                int position = i;

                Button button = buttonsUi[position];

                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(delegate () {
                    _cpuInventory.Attach(position);
                });
            }
        }
    }

    public NpcInventory GetCpuInventory() {
        return this._cpuInventory;
    }

    public void HideActualCpuInventory() { 
        if (_cpuInventory != null) {
            _cpuInventory.HideIventory();
            _cpuInventory = null;
            this.gameObject.SetActive(false);
        }
    }

}
