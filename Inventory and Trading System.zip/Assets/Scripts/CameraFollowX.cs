﻿using UnityEngine;

public class CameraFollowX : MonoBehaviour
{
    public Transform target;

    public GameObject player;

    [SerializeField] float smoothFactor = .01f;

    float leftLimit = -1.164705f;
    float rightLimit = 7.738221f;

    // Start is called before the first frame update
    void LateUpdate()
    {
        Vector2 desiredPosition = new Vector2(target.position.x, 0);
        Vector3 smoothedPosition = Vector2.Lerp(transform.position, desiredPosition, smoothFactor);
        smoothedPosition.z = -10;
        if ((transform.position.x >= leftLimit) && (transform.position.x <= rightLimit))
        {
            transform.position = smoothedPosition;
        }
    }
}