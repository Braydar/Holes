﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ItemGroup { 
    GROUP1, GROUP2, GROUP3, GROUP4, GROUP5
}
